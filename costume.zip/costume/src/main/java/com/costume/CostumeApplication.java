package com.costume;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CostumeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CostumeApplication.class, args);
	}

}
